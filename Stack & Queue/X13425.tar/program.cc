#include "CuaIOParInt.hh"
#include<iostream>
#include<queue>

using namespace std;

void optimizar(queue<ParInt> &a,queue<ParInt> &b,queue<ParInt> &c) 
{
    int temps1 = 0;
    int temps2 = 0;
    while (!a.empty()) 
    {
        if (temps1 <= temps2) 
        {
            b.push(a.front());
            temps1 += a.front().segon();
        }
        else 
        {
            c.push(a.front());
            temps2 += a.front().segon();
        }
        a.pop();

    }
}


int main() 
{
    ParInt a;
    queue<ParInt> inicial;
    llegirCuaParInt(inicial);
    queue<ParInt> primera,segunda;
    optimizar(inicial, primera,segunda);
    escriureCuaParInt(primera);
    cout << endl;
    escriureCuaParInt(segunda);
}