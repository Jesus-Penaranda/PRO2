#include "LlistaIOParInt.hh"
#include<iostream>
#include<iterator>

void LlegirLlistaParInt(list<ParInt>& l) {
    
    list <ParInt> :: iterator it = l.begin();
    int num1, num2;
    while(cin >> num1 >> num2 and (num1 != 0 and num2 != 0)) {
        l.insert(it,ParInt(num1,num2));
    }

}
void EscriureLlistaParInt(const list<ParInt>& l, int n, int &s, int &a) {
    list <ParInt> :: const_iterator inici = l.begin();
    list <ParInt> :: const_iterator final = l.end();
    while(inici != final) {
        if((*inici).primer() == n) {
            ++a;
            s += (*inici).segon();

        }
        ++inici;
    }
}
