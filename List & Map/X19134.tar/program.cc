#include "LlistaIOParInt.hh"

using namespace std;

int main () {
 
    list <ParInt> nums;
    LlegirLlistaParInt(nums);
    int vegades = 0;
    int sumatotal = 0;
    int n;
    cin >> n;
    EscriureLlistaParInt(nums, n, sumatotal, vegades);
    cout << n << ' ' << vegades << ' ' << sumatotal << endl;

}